//
//  ViewController.swift
//  weather
//
//  Created by слепцова кристина on 12.03.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var cityNameLabel: UILabel!
    @IBOutlet weak var cityTempLabel: UILabel!
    @IBOutlet weak var country: UILabel!
    @IBOutlet weak var day: UILabel!
    @IBOutlet weak var weather: UILabel!
    @IBOutlet weak var textfield: UITextField!
    
    @IBAction func showCityNameAction(_ sender: Any)
    {
        let urlString = "https://api.weatherapi.com/v1/current.json?key=02e8f96450b14c9181232950221203&q=\(textfield.text!)"
        let url = URL(string: urlString)
        
        let session = URLSession(configuration: .default)
        
        let task = session.dataTask(with: url!) { data, response, error in
            if let data = data {
                /*let dataString = String(data: data, encoding: .utf8)
                print(dataString!)*/
                self.parseJSON(withData: data)
            }
        }
        task.resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let colorOne = UIColor (red: 255, green: 193, blue: 192, alpha: 1.0)
        let colorTwo = UIColor (red: 198, green: 129, blue: 141, alpha: 1.0)
        let gradient = CAGradientLayer()
        gradient.frame = self.view.bounds
        gradient.colors = [colorOne.cgColor, colorTwo.cgColor]
        self.view.layer.insertSublayer(gradient, at: 0)
        
    }
    
    func parseJSON(withData data: Data) {
        
        let decoder = JSONDecoder()
        
        do {
            
            let apiItem = try decoder.decode(Welcome.self, from: data)
            
            cityNameLabel.text = apiItem.location.name
            cityTempLabel.text = String(apiItem.current.tempC)
            day.text = String(apiItem.location.localtime)
            country.text = apiItem.location.country
            weather.text = apiItem.current.condition.text
        }
        catch let error as NSError {
            print(error.localizedDescription)
        }
    }
}

