//
//  secure.swift
//  weather
//
//  Created by слепцова кристина on 12.03.2022.
//

import Foundation

let apiKey = "02e8f96450b14c9181232950221203"
